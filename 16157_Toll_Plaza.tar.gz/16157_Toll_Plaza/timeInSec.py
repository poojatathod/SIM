

def timeInSec(t):
    h,m =map(int, t.split(":"))
    sec=(h*60*60)+(m*60) 
    return sec
    

